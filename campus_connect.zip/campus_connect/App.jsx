import React, { useState, useEffect, useRef } from 'react';
import { 
  Building2, Users, GraduationCap, Award, Briefcase, FileCheck, 
  DollarSign, AlertTriangle, MapPin, FileText, Play, Pause, SkipForward, 
  Volume2, VolumeX, CheckCircle, Clock, Calendar, ChevronRight, X, 
  Search, Bell, Sparkles, User, Shield, Info, ArrowRight, ExternalLink,
  QrCode, BookOpen, Layers, Check, RefreshCw, Send, Plus, Download, Eye,
  HelpCircle, Compass, Radio
} from 'lucide-react';

// --- INITIAL PROTOTYPE DATA ---
const INITIAL_STUDENT = {
  name: "Alex Morgan",
  rollNo: "21B91A0588",
  branch: "Computer Science & Engineering (CSE - Sec B)",
  email: "alex.morgan@campus.edu",
  role: "Student", // Student, Class Representative, Club Member, Club Coordinator, Admin
  scholarship: "Recipient", // Recipient, Non-recipient
  year: "3rd Year"
};

const SAMPLE_CLUBS = [
  {
    id: 'sdc',
    name: 'Student Developers Club (SDC)',
    category: 'Technical',
    badge: 'Tech & Innovation',
    description: 'SDC encourages students to move beyond classroom theory and gain practical experience through hackathons, coding competitions, software & web development workshops, technical bootcamps, AI/ML sessions, and open-source contributions.',
    motto: 'Code. Create. Innovate.',
    membersCount: 340,
    tags: ['Web Dev', 'AI / ML', 'Open Source', 'Hackathons'],
    color: 'from-blue-600 to-indigo-600',
    image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=800',
    boardMembers: [
      { role: 'Faculty Advisor', name: 'Dr. K. S. Raman', contact: '+91 98765 01234' },
      { role: 'Student President', name: 'Rohan Sharma', contact: '+91 98123 45678' },
      { role: 'Lead Developer', name: 'Priya Verma', contact: '+91 98234 56789' }
    ],
    activities: [
      'Annual 24-Hour Hackathon "HackCampus"',
      'Git & GitHub Open Source Bootcamp',
      'Full-Stack Web App Development Workshop',
      'AI/ML Model Building Hands-on Sessions'
    ]
  },
  {
    id: 'nss',
    name: 'National Service Scheme (NSS)',
    category: 'Social Service',
    badge: 'Civic Engagement',
    description: 'NSS promotes social responsibility, volunteering, community participation, leadership, and civic awareness among students through meaningful impact initiatives across surrounding villages.',
    motto: 'NOT ME BUT YOU',
    membersCount: 520,
    tags: ['Blood Donation', 'Tree Plantation', 'Cleanliness', 'Community'],
    color: 'from-emerald-600 to-teal-600',
    image: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&q=80&w=800',
    boardMembers: [
      { role: 'NSS Program Officer', name: 'Prof. M. Anitha', contact: '+91 97654 32109' },
      { role: 'Student Coordinator', name: 'Vikram Reddy', contact: '+91 98456 78901' },
      { role: 'Volunteers Lead', name: 'Ananya Roy', contact: '+91 98567 89012' }
    ],
    activities: [
      'Mega Blood Donation Drive in Association with Red Cross',
      'Campus & Green Belt Tree Plantation Drive',
      'Clean India & Rural Digital Literacy Camps',
      'Health & Hygiene Awareness Workshops'
    ]
  },
  {
    id: 'arts',
    name: 'Arts & Cultural Club',
    category: 'Arts & Culture',
    badge: 'Creative Express',
    description: 'Provides visibility to creative communities and helps students express talents in music, dance, theatre, visual arts, sketching, and digital graphic design.',
    motto: 'Express, Inspire, Transform.',
    membersCount: 280,
    tags: ['Choreography', 'Live Music', 'Drama & Theatre', 'Digital Art'],
    color: 'from-purple-600 to-pink-600',
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800',
    boardMembers: [
      { role: 'Faculty Convenor', name: 'Dr. Archana Sen', contact: '+91 99887 76655' },
      { role: 'Cultural Secretary', name: 'Karthik Raja', contact: '+91 98678 90123' },
      { role: 'Arts Coordinator', name: 'Sanya Malhotra', contact: '+91 98789 01234' }
    ],
    activities: [
      'Annual Inter-College Cultural Fest "Spandan"',
      'Acoustic Music Jam & Battle of Bands',
      'Street Play & Social Awareness Theatre',
      'Canvas Painting & Digital Art Exhibition'
    ]
  },
  {
    id: 'sports',
    name: 'Campus Sports Society',
    category: 'Sports',
    badge: 'Athletics & Fitness',
    description: 'Organizes intra-college tournaments, fitness bootcamps, and trains students for inter-university athletic and sports championships.',
    motto: 'Stronger, Faster, Together.',
    membersCount: 410,
    tags: ['Cricket', 'Basketball', 'Athletics', 'Chess & Esports'],
    color: 'from-amber-600 to-orange-600',
    image: 'https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&q=80&w=800',
    boardMembers: [
      { role: 'Physical Director', name: 'Coach R. Suresh', contact: '+91 91234 56789' },
      { role: 'Sports Secretary', name: 'David Kumar', contact: '+91 92345 67890' }
    ],
    activities: [
      'Annual Sports League "Pinnacle"',
      'Night Cricket Championship',
      'Inter-Departmental Football Cup'
    ]
  }
];

const SAMPLE_EVENTS = [
  {
    id: 1,
    title: 'HackCampus 2026 - 24hr Hackathon',
    club: 'Student Developers Club (SDC)',
    clubId: 'sdc',
    date: 'Oct 28, 2026',
    time: '09:00 AM - 09:00 AM (Next Day)',
    location: 'Main Auditorium & Computer Labs',
    capacity: '200 participants',
    registered: 142,
    status: 'Open',
    category: 'Technical',
    description: 'Build innovative web/mobile or AI solutions for real-world campus problems within 24 hours. Cash prizes worth ₹50,000!'
  },
  {
    id: 2,
    title: 'NSS Blood Donation & Free Health Checkup',
    club: 'National Service Scheme (NSS)',
    clubId: 'nss',
    date: 'Nov 02, 2026',
    time: '10:00 AM - 04:00 PM',
    location: 'Student Activity Center (SAC) Hall B',
    capacity: '300 Donors',
    registered: 185,
    status: 'Open',
    category: 'Social Service',
    description: 'Join hands with Red Cross Society for our annual blood donation camp. Donors receive certificates & refreshers.'
  },
  {
    id: 3,
    title: 'Spandan 2026 - Cultural Auditions',
    club: 'Arts & Cultural Club',
    clubId: 'arts',
    date: 'Nov 05, 2026',
    time: '02:00 PM - 06:00 PM',
    location: 'Open Air Theatre (OAT)',
    capacity: '100 Performers',
    registered: 64,
    status: 'Open',
    category: 'Arts & Culture',
    description: 'Showcase your talent in Dance, Music, Theatre, or Stand-up comedy to qualify for the main fest.'
  },
  {
    id: 4,
    title: 'Inter-Departmental Cricket Tournament',
    club: 'Campus Sports Society',
    clubId: 'sports',
    date: 'Nov 10, 2026',
    time: '08:30 AM - 05:00 PM',
    location: 'Sports Complex Main Ground',
    capacity: '16 Teams',
    registered: 12,
    status: 'Open',
    category: 'Sports',
    description: 'T20 Knockout championship between all department branches.'
  },
  {
    id: 5,
    title: 'AI & Machine Learning Workshop',
    club: 'Student Developers Club (SDC)',
    clubId: 'sdc',
    date: 'Nov 14, 2026',
    time: '01:30 PM - 04:30 PM',
    location: 'Seminar Hall 2, Tech Block',
    capacity: '80 Students',
    registered: 78,
    status: 'Filling Fast',
    category: 'Technical',
    description: 'Hands-on practical introduction to LLMs, Neural Networks, and Python AI libraries.'
  }
];

const SAMPLE_CERTIFICATES = [
  { id: 1, title: 'Winner - Web Hackathon 2025', issuer: 'Student Developers Club (SDC)', date: '15 Dec 2025', verified: true, code: 'CERT-SDC-2025-9981' },
  { id: 2, title: 'NSS Special Village Camp Certificate', issuer: 'National Service Scheme', date: '20 Nov 2025', verified: true, code: 'CERT-NSS-2025-4421' },
  { id: 3, title: 'Full Stack Web Bootcamp', issuer: 'Department of Computer Science', date: '10 Oct 2025', verified: true, code: 'CERT-CSE-2025-1102' },
  { id: 4, title: 'Spandan Dance Coordinator', issuer: 'Arts & Cultural Club', date: '05 May 2025', verified: true, code: 'CERT-ART-2025-3004' },
  { id: 5, title: 'Git & Open Source Workshop', issuer: 'Student Developers Club (SDC)', date: '12 Feb 2026', verified: true, code: 'CERT-SDC-2026-0129' },
  { id: 6, title: 'Blood Donation Donor Badge', issuer: 'Red Cross & NSS', date: '18 Jan 2026', verified: true, code: 'CERT-NSS-2026-8832' },
  { id: 7, title: 'AI & Data Science Summit', issuer: 'IEEE Student Branch', date: '02 Sep 2026', verified: false, code: 'PENDING-VERIFICATION' },
  { id: 8, title: 'Inter-College Sports League Volley', issuer: 'Campus Sports Society', date: '25 Sep 2026', verified: false, code: 'PENDING-VERIFICATION' }
];

const SAMPLE_PLACEMENTS = [
  { company: 'Google India', role: 'Software Development Engineer (SDE-1)', ctc: '₹24 LPA', drivesDate: 'Nov 12, 2026', status: 'Upcoming Drive', eligible: 'CSE / IT (CGPA > 8.0)' },
  { company: 'Microsoft', role: 'Support Engineer / Technical Analyst', ctc: '₹18 LPA', drivesDate: 'Nov 15, 2026', status: 'Applications Open', eligible: 'All Tech Branches (CGPA > 7.5)' },
  { company: 'TCS Digital', role: 'System Engineer Specialist', ctc: '₹7.5 LPA', drivesDate: 'Nov 20, 2026', status: 'Applications Open', eligible: 'All Circuit Branches' },
  { company: 'Accenture', role: 'Advanced Application Engineering Analyst', ctc: '₹6.5 LPA', drivesDate: 'Nov 25, 2026', status: 'Shortlisting Phase', eligible: 'All Branches Eligible' },
  { company: 'Infosys Power Programmer', role: 'Specialist Programmer', ctc: '₹9.5 LPA', drivesDate: 'Dec 02, 2026', status: 'Upcoming Drive', eligible: 'CSE / ECE / EEE' },
  { company: 'Cognizant GenC Next', role: 'Software Engineer', ctc: '₹6.8 LPA', drivesDate: 'Dec 08, 2026', status: 'Upcoming Drive', eligible: 'All B.Tech Streams' }
];

const SAMPLE_APPROVALS = [
  { id: 'REQ-8891', title: 'Seminar Hall 2 Booking for SDC AI Workshop', requestedBy: 'Alex Morgan (SDC)', date: 'Nov 14, 2026', facility: 'Seminar Hall 2', status: 'Approved', level: 'Faculty Incharge Verified' },
  { id: 'REQ-8904', title: 'Sound Equipment Permission for Music Jam', requestedBy: 'Arts Club Representative', date: 'Nov 05, 2026', facility: 'Open Air Theatre (OAT)', status: 'Pending Faculty Review', level: 'Dean Office Processing' }
];

// --- DOCUMENTARY SCRIPT DEFINITION ---
const DOCUMENTARY_SCENES = [
  {
    id: 'intro',
    title: '1. Problem & Vision',
    subtitle: 'The Fragmented Campus Experience',
    narration: 'Every day across college campuses, thousands of students navigate a fragmented digital landscape. Academic notices on college portals, event flyers on WhatsApp groups, club approvals trapped in printed letters, and achievements lost across disconnected forms. Introducing Campus Connect — One platform for your complete campus life. Designed to unify students, clubs, academics, and administration into one seamless digital ecosystem.',
    activeView: 'dashboard',
    highlightTarget: 'hero',
    overlayVisual: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'login',
    title: '2. Role-Based Entry',
    subtitle: 'Personalized Profile & Identification',
    narration: 'The journey begins at the unified entry portal. By capturing student details including Roll Number, Branch, Category, and Scholarship status, Campus Connect automatically customizes permissions, notices, and privileges based on whether you are a Student, Class Representative, Club Coordinator, or Scholarship Recipient.',
    activeView: 'login',
    highlightTarget: 'loginForm'
  },
  {
    id: 'dashboard',
    title: '3. The Central Dashboard',
    subtitle: 'Real-Time Campus Life Command Center',
    narration: 'Welcome to the Central Dashboard. Designed with a modern soft blue and purple visual aesthetic, students immediately gain a clear high-level view of their campus footprint: active club memberships, verified certificates, upcoming registered events, and pending administrative requests — all updated in real-time.',
    activeView: 'dashboard',
    highlightTarget: 'statsGrid'
  },
  {
    id: 'clubs_sdc',
    title: '4. Club Ecosystem — SDC',
    subtitle: 'Hands-on Technical & Peer Growth',
    narration: 'Campus Connect brings student communities to life through the Clubs & Communities directory. Here in the Student Developers Club profile, students discover hackathons, open-source projects, and technical bootcamps. Verified board contact details and direct event registration turn passive learning into practical project execution.',
    activeView: 'clubs',
    highlightClub: 'sdc'
  },
  {
    id: 'clubs_nss',
    title: '5. Social Responsibility — NSS',
    subtitle: 'Building Civic Awareness ("NOT ME BUT YOU")',
    narration: 'Under the motto "NOT ME BUT YOU", the National Service Scheme profile connects students with blood donation drives, environmental campaigns, and community engagement initiatives. Discovering opportunities to give back to society has never been more organized or accessible.',
    activeView: 'clubs',
    highlightClub: 'nss'
  },
  {
    id: 'academics_certs',
    title: '6. Academics & Verified Records',
    subtitle: 'Central Resources & Portfolio Building',
    narration: 'Beyond extracurriculars, the platform centralizes academic timetables, exam notices, and study material. Simultaneously, the Certificates module maintains a verified ledger of every workshop, hackathon, and volunteer badge earned — forming a trustworthy digital portfolio for future careers.',
    activeView: 'certificates',
    highlightTarget: 'certStats'
  },
  {
    id: 'placements_approvals',
    title: '7. Placements & Paperless Workflows',
    subtitle: 'Career Readiness & Digital Approvals',
    narration: 'Stay ahead with the Placements module, showcasing real-time drive listings, CTC breakdowns, and eligibility criteria. Meanwhile, the Online Approvals system digitizes paper permission slips for seminar halls and event equipment, replacing manual follow-ups with transparent multi-stage status tracking.',
    activeView: 'approvals',
    highlightTarget: 'approvalsList'
  },
  {
    id: 'conflict_nav',
    title: '8. Smart Operations & Campus Tools',
    subtitle: 'Conflict Detection & Navigation Guides',
    narration: 'To prevent overlapping events, the Conflict Check module flags venue double-bookings before schedules are finalized. Combined with the interactive Campus Map and step-by-step Document Requirements Guide, students save hours of administrative confusion.',
    activeView: 'conflict',
    highlightTarget: 'conflictBox'
  },
  {
    id: 'conclusion',
    title: '9. Conclusion & Impact',
    subtitle: 'Transforming Campus Life Together',
    narration: 'Campus Connect transforms scattered campus activities into one connected and verified Campus Journey for every student. Empowering students to learn, lead, collaborate, and thrive. Thank you!',
    activeView: 'dashboard',
    highlightTarget: 'thankyouModal'
  }
];

export default function App() {
  // Application State
  const [student, setStudent] = useState(INITIAL_STUDENT);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [registeredEventIds, setRegisteredEventIds] = useState([1]);
  const [toastMessage, setToastMessage] = useState(null);
  
  // Modals state
  const [selectedClub, setSelectedClub] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [registeredQrBadge, setRegisteredQrBadge] = useState(null);
  const [viewCertificateModal, setViewCertificateModal] = useState(null);

  // New Approval Request form
  const [approvalTitle, setApprovalTitle] = useState('');
  const [approvalFacility, setApprovalFacility] = useState('Seminar Hall 1');
  const [approvalDate, setApprovalDate] = useState('2026-11-12');
  const [approvalsList, setApprovalsList] = useState(SAMPLE_APPROVALS);

  // Documentary Mode State
  const [documentaryMode, setDocumentaryMode] = useState(false);
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isDocumentaryPlaying, setIsDocumentaryPlaying] = useState(false);
  const [audioMuted, setAudioMuted] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);

  // Speech Synthesis ref
  const speechSynthRef = useRef(null);

  // Show Toast
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Login handler
  const handleLogin = (e) => {
    if (e) e.preventDefault();
    setIsLoggedIn(true);
    showToast(`Welcome back, ${student.name}! Profile initialized as ${student.role}.`);
  };

  // Event Registration handler
  const handleRegisterEvent = (event) => {
    if (registeredEventIds.includes(event.id)) {
      showToast(`You are already registered for ${event.title}`);
      return;
    }
    setRegisteredEventIds([...registeredEventIds, event.id]);
    setRegisteredQrBadge(event);
    showToast(`Successfully registered for ${event.title}! QR Pass generated.`);
  };

  // Create Approval Request
  const handleCreateApproval = (e) => {
    e.preventDefault();
    if (!approvalTitle) return;
    const newReq = {
      id: `REQ-${Math.floor(1000 + Math.random() * 9000)}`,
      title: approvalTitle,
      requestedBy: `${student.name} (${student.role})`,
      date: approvalDate,
      facility: approvalFacility,
      status: 'Pending Faculty Review',
      level: 'Department Head Reviewing'
    };
    setApprovalsList([newReq, ...approvalsList]);
    setApprovalTitle('');
    showToast('Permission request submitted successfully!');
  };

  // Speech helper for documentary
  const speakText = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Stop current speech
      if (audioMuted) return;
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Documentary Scene Effect
  useEffect(() => {
    if (!documentaryMode) {
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      setShowThankYou(false);
      return;
    }

    const scene = DOCUMENTARY_SCENES[currentSceneIndex];
    if (scene) {
      setActiveTab(scene.activeView);
      if (scene.highlightClub) {
        const club = SAMPLE_CLUBS.find(c => c.id === scene.highlightClub);
        if (club) setSelectedClub(club);
      } else {
        setSelectedClub(null);
      }

      if (scene.id === 'conclusion') {
        setShowThankYou(true);
      } else {
        setShowThankYou(false);
      }

      if (isDocumentaryPlaying) {
        speakText(scene.narration);
      }
    }
  }, [documentaryMode, currentSceneIndex, isDocumentaryPlaying]);

  // Auto-advance scenes when playing
  useEffect(() => {
    let timer;
    if (documentaryMode && isDocumentaryPlaying) {
      // Scene duration approximately 12 seconds per slide
      timer = setTimeout(() => {
        if (currentSceneIndex < DOCUMENTARY_SCENES.length - 1) {
          setCurrentSceneIndex(prev => prev + 1);
        } else {
          setIsDocumentaryPlaying(false);
          showToast('Documentary storyline complete!');
        }
      }, 13000);
    }
    return () => clearTimeout(timer);
  }, [documentaryMode, isDocumentaryPlaying, currentSceneIndex]);

  const toggleDocumentaryMode = () => {
    if (!documentaryMode) {
      setDocumentaryMode(true);
      setCurrentSceneIndex(0);
      setIsDocumentaryPlaying(true);
      showToast('Cinematic Documentary Mode Activated!');
    } else {
      setDocumentaryMode(false);
      setIsDocumentaryPlaying(false);
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      showToast('Exited Documentary Mode.');
    }
  };

  const handleNextScene = () => {
    if (currentSceneIndex < DOCUMENTARY_SCENES.length - 1) {
      setCurrentSceneIndex(prev => prev + 1);
    }
  };

  const handlePrevScene = () => {
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col selection:bg-indigo-500 selection:text-white">
      
      {/* --- TOAST NOTIFICATION --- */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-indigo-600 text-white px-5 py-3 rounded-xl shadow-2xl border border-indigo-400 flex items-center space-x-3 animate-bounce">
          <Sparkles className="w-5 h-5 text-amber-300 flex-shrink-0" />
          <span className="text-sm font-medium">{toastMessage}</span>
        </div>
      )}

      {/* --- TOP HEADER / NAVBAR --- */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 lg:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-tr from-indigo-600 to-purple-600 p-2 rounded-xl shadow-lg shadow-indigo-500/20">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400">
                Campus Connect
              </span>
              <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-indigo-950 text-indigo-300 rounded-full border border-indigo-700/50">
                v2.4 Production
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">One platform for your complete campus life.</p>
          </div>
        </div>

        {/* Action Controls & Documentary Button */}
        <div className="flex items-center space-x-3">
          {/* CINEMATIC DOCUMENTARY TRIGGER BUTTON */}
          <button
            onClick={toggleDocumentaryMode}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-lg ${
              documentaryMode
                ? 'bg-rose-600 hover:bg-rose-500 text-white ring-2 ring-rose-400 animate-pulse'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-900/40'
            }`}
          >
            <Radio className="w-4 h-4 animate-spin" />
            <span>{documentaryMode ? 'Exit Documentary' : 'Play Cinematic Documentary'}</span>
          </button>

          {isLoggedIn ? (
            <div className="flex items-center space-x-3 border-l border-slate-800 pl-3">
              <div className="hidden md:block text-right">
                <p className="text-xs font-semibold text-slate-200">{student.name}</p>
                <p className="text-[10px] text-indigo-400">{student.role} • {student.branch.split('(')[0]}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-inner border border-indigo-400/30">
                {student.name.charAt(0)}
              </div>
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('login')}
              className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl font-medium"
            >
              Sign In
            </button>
          )}
        </div>
      </header>

      {/* --- CINEMATIC DOCUMENTARY TOP CONTROL BANNER --- */}
      {documentaryMode && (
        <div className="bg-slate-900 border-b border-purple-500/30 px-4 py-3 sticky top-[61px] z-30 shadow-2xl">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
              </span>
              <div>
                <span className="text-xs text-purple-400 uppercase tracking-wider font-bold">Documentary Storyline</span>
                <h4 className="text-sm font-extrabold text-white">
                  {DOCUMENTARY_SCENES[currentSceneIndex].title}: {DOCUMENTARY_SCENES[currentSceneIndex].subtitle}
                </h4>
              </div>
            </div>

            {/* Narration Text Box */}
            <div className="flex-1 max-w-2xl bg-slate-950/80 p-2.5 rounded-lg border border-purple-900/50 text-xs text-slate-300 italic shadow-inner">
              "{DOCUMENTARY_SCENES[currentSceneIndex].narration}"
            </div>

            {/* Scene Playback Controls */}
            <div className="flex items-center space-x-2">
              <button
                onClick={handlePrevScene}
                disabled={currentSceneIndex === 0}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 rounded-lg text-slate-200"
                title="Previous Scene"
              >
                <ChevronRight className="w-4 h-4 rotate-180" />
              </button>
              
              <button
                onClick={() => setIsDocumentaryPlaying(!isDocumentaryPlaying)}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 rounded-lg text-xs font-bold text-white flex items-center space-x-1"
              >
                {isDocumentaryPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isDocumentaryPlaying ? 'Pause' : 'Play'}</span>
              </button>

              <button
                onClick={handleNextScene}
                disabled={currentSceneIndex === DOCUMENTARY_SCENES.length - 1}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 rounded-lg text-slate-200"
                title="Next Scene"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setAudioMuted(!audioMuted);
                  if (!audioMuted && 'speechSynthesis' in window) window.speechSynthesis.cancel();
                }}
                className={`p-1.5 rounded-lg text-slate-200 ${audioMuted ? 'bg-rose-900/50 text-rose-300' : 'bg-slate-800'}`}
                title={audioMuted ? 'Unmute Narration' : 'Mute Narration'}
              >
                {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- MAIN LAYOUT (SIDEBAR + CONTENT) --- */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* SIDEBAR NAVIGATION */}
        <aside className="w-64 bg-slate-900 border-r border-slate-800 flex-shrink-0 hidden lg:flex flex-col justify-between p-4">
          <div className="space-y-6">
            <div>
              <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Main Menu</p>
              <nav className="space-y-1">
                {[
                  { id: 'dashboard', label: 'Dashboard', icon: Layers },
                  { id: 'clubs', label: 'Clubs & Communities', icon: Users, badge: '4 Active' },
                  { id: 'academics', label: 'Academics & Timetable', icon: GraduationCap },
                  { id: 'certificates', label: 'Certificates Portfolio', icon: Award, badge: '6 Verified' },
                  { id: 'placements', label: 'Placements & Drives', icon: Briefcase, badge: '42 Companies' },
                  { id: 'approvals', label: 'Online Approvals', icon: FileCheck, badge: '2 Pending' },
                  { id: 'scholarships', label: 'Scholarships Portal', icon: DollarSign },
                  { id: 'conflict', label: 'Event Conflict Check', icon: AlertTriangle }
                ].map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-600/30'
                          : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      {item.badge && (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                          isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-indigo-300'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            <div>
              <p className="px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Campus Tools</p>
              <nav className="space-y-1">
                {[
                  { id: 'map', label: 'Campus Map & Finder', icon: MapPin },
                  { id: 'docs', label: 'Document Guide', icon: FileText }
                ].map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        isActive
                          ? 'bg-indigo-600 text-white shadow-md'
                          : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* User Profile Card Footbar */}
          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800/80">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center font-bold text-white text-xs">
                {student.name.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-semibold text-slate-200 truncate">{student.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{student.rollNo}</p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('login')}
              className="mt-2.5 w-full text-center text-[10px] font-semibold text-indigo-400 hover:text-indigo-300 bg-indigo-950/50 py-1.5 rounded-lg border border-indigo-900/40"
            >
              Switch Role / Edit Profile
            </button>
          </div>
        </aside>

        {/* MOBILE NAVIGATION TAB BAR */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900 border-t bor